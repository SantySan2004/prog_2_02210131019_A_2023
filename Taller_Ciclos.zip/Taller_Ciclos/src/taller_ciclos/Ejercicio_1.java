package taller_ciclos;

import java.util.Scanner;

public class Ejercicio_1 {

    
    
public static void reversoStringFor(String palabra){
    for (int i = palabra.length() - 1; i >= 0; i--) {
        //Nos posicionamos en la última posición de la cadena e imprimimos el texto hacía el final de la cadena de caracteres
      System.out.print(palabra.charAt(i));
    }
    System.out.println();
}

public static void reversoStringWhile(String palabra){
    int i = palabra.length() - 1;
    //De igual forma en el ciclo while mientras se cumpla la condición de i, se imprime desde la ultima posición, luego el ciclo acaba
    while (i >= 0) {
      System.out.print(palabra.charAt(i));
      i--;
    }
    System.out.println();
}

public static void reversoStringDoWhile(String palabra){
    int i = palabra.length() - 1;
    //En este ciclo se genera un bloque en el do, que se ejecuta siempre y cuando se cumpla el while, de igual forma imprimiendo hacia atrás la cadena
    do {
      System.out.print(palabra.charAt(i));
      i--;
    } while (i >= 0);
    System.out.println();
}

public static void main(String[] args) {
  
    Scanner sc = new Scanner(System.in);
        
    System.out.println("Ingrese una palabra: ");
    String palabra = sc.nextLine();

    System.out.println("Reverso usando for: ");
    reversoStringFor(palabra);

    System.out.println("Reverso usando while: ");
    reversoStringWhile(palabra);

    System.out.println("Reverso usando do-while: ");
    reversoStringDoWhile(palabra);
    }
}
