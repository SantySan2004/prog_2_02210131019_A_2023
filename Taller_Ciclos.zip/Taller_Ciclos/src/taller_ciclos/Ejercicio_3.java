package taller_ciclos;

import java.util.Random;

public class Ejercicio_3 {

  public static void main(String[] args) {
    imprimirInventario();
  }
  
  public static void imprimirInventario() {
    // Crear un objeto Random
    Random aleatorio = new Random();
    
    // Definir el rango de productos
    int productos = 23;
    
    System.out.println("INVENTARIO:");
    
    // Usando el ciclo for
    System.out.println("\nCICLO FOR:");
    for (int i = 1; i <= productos; i++) {
      int numeroAleatorio = aleatorio.nextInt(productos) + 1;
      System.out.println("Producto " + i + ": Espacios " + numeroAleatorio + ", Cantidad " + numeroAleatorio + ", Precio $" + numeroAleatorio + ", Último " + numeroAleatorio);
    }
    
    // Usando el ciclo while
    System.out.println("\nCICLO WHILE:");
    int j = 1;
    while (j <= productos) {
      int numeroAleatorio = aleatorio.nextInt(productos) + 1;
      System.out.println("Producto " + j + ": Espacios " + numeroAleatorio + ", Cantidad " + numeroAleatorio + ", Precio $" + numeroAleatorio + ", Último " + numeroAleatorio);
      j++;
    }
    
    // Usando el ciclo do-while
    System.out.println("\nCICLO DO-WHILE:");
    int k = 1;
    do {
      int numeroAleatorio = aleatorio.nextInt(productos) + 1;
      System.out.println("Producto " + k + ": Espacios " + numeroAleatorio + ", Cantidad " + numeroAleatorio + ", Precio $" + numeroAleatorio + ", Último " + numeroAleatorio);
      k++;
    } while (k <= productos);
  }
}
