package Arrays;

import java.util.Scanner;


public class Ejercicio_2 {


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] numeros = new int[10]; // Creamos un array de tamaño 10 para almacenar los números

        for (int i = 0; i < 10; i++) { // Pedimos al usuario que ingrese los 10 números
            System.out.print("Ingrese el número " + (i+1) + ": ");
            numeros[i] = sc.nextInt();
        }

        int max = numeros[0]; // Inicializamos el máximo con el primer número del array
        int min = numeros[0]; // Inicializamos el mínimo con el primer número del array

        for (int i = 1; i < 10; i++) { // Buscamos el máximo y el mínimo en el array
            if (numeros[i] > max) {
                max = numeros[i];
            }
            if (numeros[i] < min) {
                min = numeros[i];
            }
        }

        System.out.println("Los números introducidos son: ");
        for (int i = 0; i < 10; i++) { // Imprimimos los números introducidos
            System.out.print(numeros[i] + " ");
            if (numeros[i] == max) { // Si el número es el máximo, mostramos "máximo" al lado
                System.out.print("(máximo) ");
            }
            if (numeros[i] == min) { // Si el número es el mínimo, mostramos "mínimo" al lado
                System.out.print("(mínimo) ");
            }
        }
    }
}
