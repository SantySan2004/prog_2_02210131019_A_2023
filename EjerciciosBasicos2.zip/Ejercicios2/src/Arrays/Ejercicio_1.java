package Arrays;

import java.util.Scanner;


public class Ejercicio_1 {


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] numeros = new int[10]; // Creamos un array de tamaño 10 para almacenar los números

        for (int i = 0; i < 10; i++) { // Pedimos al usuario que ingrese los 10 números
            System.out.print("Ingrese el número " + (i+1) + ": ");
            numeros[i] = sc.nextInt();
        }

        System.out.println("Los números en orden inverso son: ");
        for (int i = 9; i >= 0; i--) { // Imprimimos los números en orden inverso
            System.out.print(numeros[i] + " ");
        }
    }
}
