package Arrays;

import java.util.Random;
import java.util.Scanner;


public class Ejercicio_4 {


    public static void main(String[] args) {
        Random rand = new Random();
        int[][] numeros = new int[4][5]; // Creamos un array de 4 filas por 5 columnas para almacenar los números

        for (int i = 0; i < 4; i++) { // Generamos 20 números aleatorios y los asignamos al array
            for (int j = 0; j < 5; j++) {
                numeros[i][j] = rand.nextInt(900) + 100; // Generamos un número aleatorio entre 100 y 999
            }
        }

        System.out.println("La tabla de números aleatorios es: ");
        int sumaTotal = 0;
        for (int i = 0; i < 4; i++) { // Imprimimos los números aleatorios y calculamos la suma total
            int sumaFila = 0;
            for (int j = 0; j < 5; j++) {
                System.out.print(numeros[i][j] + "\t");
                sumaFila += numeros[i][j]; // Sumamos los números de la fila actual
                sumaTotal += numeros[i][j]; // Sumamos los números para la suma total
            }
            System.out.println("| " + sumaFila); // Mostramos la suma parcial de la fila
        }

        for (int j = 0; j < 5; j++) { // Imprimimos las sumas parciales de las columnas
            System.out.print("_____\t");
        }
        System.out.println("_______");

        for (int j = 0; j < 5; j++) { // Calculamos las sumas parciales de las columnas
            int sumaColumna = 0;
            for (int i = 0; i < 4; i++) {
                sumaColumna += numeros[i][j]; // Sumamos los números de la columna actual
            }
            System.out.print(sumaColumna + "\t"); // Mostramos la suma parcial de la columna
        }
        System.out.println("| " + sumaTotal);
    }
}
