package Arrays;

import java.util.Scanner;


public class Ejercicio_3 {


    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
        int[][] numeros = new int[4][5]; // Creamos un array de 4 filas por 5 columnas para almacenar los números

        for (int i = 0; i < 4; i++) { // Pedimos al usuario que ingrese los 20 números
            for (int j = 0; j < 5; j++) {
                System.out.print("Ingrese el número en la fila " + (i+1) + " y la columna " + (j+1) + ": ");
                numeros[i][j] = sc.nextInt();
            }
        }

        System.out.println("La tabla de números ingresados es: ");
        int sumaTotal = 0;
        for (int i = 0; i < 4; i++) { // Imprimimos los números ingresados y calculamos la suma total
            int sumaFila = 0;
            for (int j = 0; j < 5; j++) {
                System.out.print(numeros[i][j] + "\t");
                sumaFila += numeros[i][j]; // Sumamos los números de la fila actual
                sumaTotal += numeros[i][j]; // Sumamos los números para la suma total
            }
            System.out.println("| " + sumaFila); // Mostramos la suma parcial de la fila
        }

        for (int j = 0; j < 5; j++) { // Imprimimos las sumas parciales de las columnas
            System.out.print("_____\t");
        }
        System.out.println("_______");

        for (int j = 0; j < 5; j++) { // Calculamos las sumas parciales de las columnas
            int sumaColumna = 0;
            for (int i = 0; i < 4; i++) {
                sumaColumna += numeros[i][j]; // Sumamos los números de la columna actual
            }
            System.out.print(sumaColumna + "\t"); // Mostramos la suma parcial de la columna
        }
        System.out.println("| " + sumaTotal);
    }
}
