package Bucles;

import java.util.Scanner;


public class Ejercicio_7 {


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Introduce el precio del producto: ");
        double precio = scanner.nextDouble();

        double pagoMensual = precio / 210;
        double totalPagado = 0;
        double pagoActual = 10;

        for (int i = 1; i <= 20; i++) {
            totalPagado += pagoActual;
            pagoActual *= 2;
        }

        System.out.println("El pago mensual es de " + pagoMensual + " euros.");
        System.out.println("El total pagado después de 20 meses es de " + totalPagado + " euros.");
    }
}
