package Bucles;

import java.util.Scanner;


public class Ejercicio_3 {


    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        while (true) { // Iteramos indefinidamente hasta que se introduzca un espacio
            
            System.out.println("Introduce un caracter: "); // Pedimos al usuario que introduzca un caracter
            String caracterIntroducido = entrada.nextLine(); // Leemos el caracter introducido por el usuario
            
            if (caracterIntroducido.equals(" ")) { // Si se introduce un espacio, salimos del bucle
                
                break; // Salimos del bucle while
                
            }
            
            if (caracterIntroducido.equalsIgnoreCase("a") || caracterIntroducido.equalsIgnoreCase("e") || 
                caracterIntroducido.equalsIgnoreCase("i") || caracterIntroducido.equalsIgnoreCase("o") || 
                caracterIntroducido.equalsIgnoreCase("u")) { // Si el caracter introducido es una vocal (mayúscula o minúscula)
                
                System.out.println("VOCAL"); // Imprimimos "VOCAL"
                
            } else { // Si el caracter introducido no es una vocal
                
                System.out.println("NO VOCAL"); // Imprimimos "NO VOCAL"
                
            }
            
        }
        entrada.close();
    }
}
