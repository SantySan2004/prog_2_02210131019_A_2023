package Bucles;

import java.util.Scanner;


public class Ejercicio_8 {


    public static void main(String[] args) throws InterruptedException {
         int horas = 0, minutos = 0, segundos = 0; 

        while (true) { // Iniciamos un bucle infinito para actualizar el cronómetro cada segundo
            System.out.printf("%02d:%02d:%02d\n", horas, minutos, segundos); // Mostramos por pantalla el tiempo en formato hh:mm:ss
            Thread.sleep(1000); // Esperamos un segundo antes de volver a actualizar el cronómetro

            segundos++; // Aumentamos los segundos en uno
            if (segundos == 60) { // Si hemos llegado a 60 segundos, reseteamos los segundos y aumentamos los minutos en uno
                segundos = 0;
                minutos++;
            }
            if (minutos == 60) { // Si hemos llegado a 60 minutos, reseteamos los minutos y aumentamos las horas en uno
                minutos = 0;
                horas++;
            }
            if (horas == 24) { // Si hemos llegado a 24 horas, reseteamos las horas
                horas = 0;
            }
        }
    }
}
