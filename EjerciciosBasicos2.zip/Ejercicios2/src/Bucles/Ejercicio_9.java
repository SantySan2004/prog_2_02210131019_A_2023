package Bucles;

import java.util.Scanner;


public class Ejercicio_9 {


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce la cantidad de números primos que quieres mostrar: ");
        int cantidad = sc.nextInt(); 

        int contador = 0; // Inicializamos un contador para contar cuántos números primos hemos encontrado
        int numero = 2; // Empezamos a buscar números primos a partir del número 2

        while (contador < cantidad) { 
            if (esPrimo(numero)) {
                System.out.print(numero + " ");
                contador++;
            }
            numero++;
        }
    }

   
    public static boolean esPrimo(int numero) {
        if (numero <= 1) { // Los números menores o iguales a 1 no son primos
            return false;
        }
        for (int i = 2; i <= Math.sqrt(numero); i++) { // Comprobamos si el número es divisible por algún número entre 2 y la raíz cuadrada del número
            if (numero % i == 0) { // Si es divisible, no es primo
                return false;
            }
        }
        return true; // Si no ha sido divisible por ningún número, es primo
    }
}
