package Bucles;

import java.util.Scanner;


public class Ejercicio_6 {


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Introduce la base: ");
        double base = scanner.nextDouble();
        System.out.print("Introduce el exponente: ");
        int exponente = scanner.nextInt();

        double resultado = 1;
        for (int i = 0; i < exponente; i++) {
            resultado *= base;
        }

        System.out.println(base + " elevado a " + exponente + " es igual a " + resultado);
    }
}
