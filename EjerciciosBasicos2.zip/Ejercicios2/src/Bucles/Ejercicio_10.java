package Bucles;

import java.util.Scanner;


public class Ejercicio_10 {


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese el número de filas de la pirámide: ");
        int n = sc.nextInt(); // Pedimos al usuario que ingrese el número de filas de la pirámide

        for (int i = 1; i <= n; i++) { 
            for (int j = 1; j <= n - i; j++) { // Bucle para imprimir los espacios en blanco antes de los números
                System.out.print(" ");
            }
            for (int j = 1; j <= i * 2 - 1; j++) { // Bucle para imprimir los números en la fila correspondiente
                System.out.print(i + " ");
            }
            System.out.println(); // Imprimimos un salto de línea para pasar a la siguiente fila
        }
    }
}
