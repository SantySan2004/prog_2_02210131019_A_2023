package Bucles;

import java.util.Scanner;


public class Ejercicio_4 {


    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Introduce el primer número: ");
        int primerNumero = entrada.nextInt();
        
        System.out.println("Introduce el segundo número: ");
        int segundoNumero = entrada.nextInt();
        
        System.out.println("Los números pares entre " + primerNumero + " y " + segundoNumero + " son: ");
        
        for (int i = primerNumero; i <= segundoNumero; i++) { // Iteramos desde el primer número hasta el segundo número
            
            if (i % 2 == 0) { // Si el número actual es par                
                System.out.println(i); // Imprimimos el número actual
            }
        }
        entrada.close(); // Cerramos el objeto Scanner
    }
}
