package Bucles;

import java.util.Scanner;


public class Ejercicio_2 {


    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in); 
        
        System.out.println("¿Cuántos números quieres introducir?"); 
        int cantidadNumeros = entrada.nextInt(); 
        
        int numerosPositivos = 0; // Inicializamos la cantidad de números positivos a 0
        int numerosNegativos = 0; // Inicializamos la cantidad de números negativos a 0
        int numerosIgualesCero = 0; // Inicializamos la cantidad de números iguales a 0 a 0
        
        for (int i = 1; i <= cantidadNumeros; i++) { 
            
            System.out.println("Introduce el número " + i + ": ");
            int numeroIntroducido = entrada.nextInt(); 
            
            if (numeroIntroducido > 0) { // Si el número introducido es mayor que 0
                
                numerosPositivos++; // Aumentamos la cantidad de números positivos en 1
                
            } else if (numeroIntroducido < 0) { // Si el número introducido es menor que 0
                
                numerosNegativos++; // Aumentamos la cantidad de números negativos en 1
                
            } else { // Si el número introducido es igual a 0
                
                numerosIgualesCero++; // Aumentamos la cantidad de números iguales a 0 en 1
                
            }
            
        }
        
        System.out.println("Cantidad de números positivos: " + numerosPositivos);
        System.out.println("Cantidad de números negativos: " + numerosNegativos); 
        System.out.println("Cantidad de números iguales a 0: " + numerosIgualesCero); 
        
        entrada.close();
    }
}
