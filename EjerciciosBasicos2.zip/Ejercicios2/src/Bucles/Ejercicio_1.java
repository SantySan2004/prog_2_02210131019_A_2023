package Bucles;

import java.util.Scanner;


public class Ejercicio_1 {


    public static void main(String[] args) {
         int numeroAdivinar = (int) (Math.random() * 100) + 1; // Generamos un número aleatorio entre 1 y 100
        int intentos = 10;
        
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("¡Bienvenido a Adivina el Número! Tienes 10 intentos para acertar.");
        
        while (intentos > 0) { 
            
            System.out.println("Introduce un número entre 1 y 100: "); 
            int numeroIntroducido = entrada.nextInt(); 
            
            if (numeroIntroducido == numeroAdivinar) { // Si el número introducido es igual al número a adivinar
                
                System.out.println("¡Correcto! ¡Has adivinado el número en " + (10 - intentos + 1) + " intentos!"); // Mostramos un mensaje de felicitación y el número de intentos que se han necesitado
                break; // Salimos del bucle while
                
            } else if (numeroIntroducido < numeroAdivinar) { // Si el número introducido es menor al número a adivinar
                
                System.out.println("El número a adivinar es mayor que " + numeroIntroducido + ". Te quedan " + (intentos - 1) + " intentos."); // Mostramos un mensaje indicando que el número a adivinar es mayor y cuántos intentos quedan
                
            } else { // Si el número introducido es mayor al número a adivinar
                
                System.out.println("El número a adivinar es menor que " + numeroIntroducido + ". Te quedan " + (intentos - 1) + " intentos."); // Mostramos un mensaje indicando que el número a adivinar es menor y cuántos intentos quedan
                
            }
            
            intentos--; // Restamos un intento
            
        }
        
        if (intentos == 0) { // Si se han agotado los intentos
            
            System.out.println("Lo siento, has agotado los 10 intentos. El número a adivinar era " + numeroAdivinar + "."); 
        entrada.close();
        }
    }
}
