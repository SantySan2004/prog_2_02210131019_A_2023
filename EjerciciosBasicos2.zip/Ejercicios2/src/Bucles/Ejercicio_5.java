package Bucles;

import java.util.Scanner;


public class Ejercicio_5 {


    public static void main(String[] args) {
        
       Scanner scanner = new Scanner(System.in);
        int limiteInferior, limiteSuperior;
        do {
            System.out.print("Introduce el límite inferior: ");
            limiteInferior = scanner.nextInt();
            System.out.print("Introduce el límite superior: ");
            limiteSuperior = scanner.nextInt();
            if (limiteInferior > limiteSuperior) {
                System.out.println("Error: el límite inferior no puede ser mayor que el superior.");
            }
            
        } while (limiteInferior > limiteSuperior);

        int sumaDentro = 0, fueraIntervalo = 0;
        boolean limiteInferiorEncontrado = false, limiteSuperiorEncontrado = false;

        System.out.println("Introduce números (0 para terminar):");
        int numero;
        do {
            numero = scanner.nextInt();
            if (numero > limiteInferior && numero < limiteSuperior) {
                sumaDentro += numero;
            } else if (numero != 0) {
                fueraIntervalo++;
            }
            if (numero == limiteInferior) {
                limiteInferiorEncontrado = true;
            }
            if (numero == limiteSuperior) {
                limiteSuperiorEncontrado = true;
            }
            
        } while (numero != 0);

        System.out.println("La suma de los números dentro del intervalo es: " + sumaDentro);
        System.out.println("Hay " + fueraIntervalo + " números fuera del intervalo.");
        if (limiteInferiorEncontrado) {
            System.out.println("Se ha encontrado el límite inferior del intervalo.");
        }
        if (limiteSuperiorEncontrado) {
            System.out.println("Se ha encontrado el límite superior del intervalo.");
        } 
    }
}
