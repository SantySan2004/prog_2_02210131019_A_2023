package Condicionales;

import java.util.Scanner;


public class Ejercicio_12 {


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Pedir datos al usuario
        System.out.print("Ingrese la duración de la llamada en minutos: ");
        int duracion = sc.nextInt();
        System.out.print("¿La llamada fue realizada en domingo (S) o en otro día (O)?: ");
        char dia = sc.next().charAt(0);
        System.out.print("¿La llamada fue realizada en el turno de mañana (M) o en el turno de tarde (T)?: ");
        char turno = sc.next().charAt(0);

        // Calcular costo de la llamada
        double costo = 0;
        if (duracion <= 5) {
            costo = duracion * 1;
        } else if (duracion <= 8) {
            costo = 5 + (duracion - 5) * 0.8;
        } else if (duracion <= 10) {
            costo = 7.4 + (duracion - 8) * 0.7;
        } else {
            costo = 8.4 + (duracion - 10) * 0.5;
        }

        // Calcular impuesto
        double impuesto = 0;
        if (dia == 'S') {
            impuesto = costo * 0.03;
        } else if (turno == 'M') {
            impuesto = costo * 0.15;
        } else {
            impuesto = costo * 0.1;
        }

        // Imprimir resultado
        double costoTotal = costo + impuesto;
        System.out.printf("El costo total de la llamada es de %.2f euros.%n", costoTotal);
        System.out.printf("Costo de la llamada: %.2f euros.%n", costo);
        System.out.printf("Impuesto a cargar: %.2f euros.%n", impuesto);
    }
}
