package Condicionales;

import java.util.Scanner;


public class Ejercicio_6 {


    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in); 

        System.out.print("Ingrese la nota: ");
        double nota = entrada.nextDouble();

        System.out.print("Ingrese la edad: ");
        int edad = entrada.nextInt(); 

        System.out.print("Ingrese el sexo (M o F): ");
        char sexo = entrada.next().charAt(0); 

        // Si la nota es mayor o igual a 5, la edad es mayor o igual a 18 y el sexo es masculino, la solicitud es posible
        if (nota >= 5 && edad >= 18 && sexo == 'M') {
            System.out.println("La solicitud es POSIBLE.");
        }
        // Si la nota es mayor o igual a 5, la edad es mayor o igual a 18 y el sexo es femenino, la solicitud es aceptada
        else if (nota >= 5 && edad >= 18 && sexo == 'F') {
            System.out.println("La solicitud es ACEPTADA.");
        }
        // En cualquier otro caso, la solicitud es no aceptada
        else {
            System.out.println("La solicitud NO FUE ACEPTADA.");
        }
    }
}
