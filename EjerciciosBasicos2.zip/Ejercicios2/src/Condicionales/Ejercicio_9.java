package Condicionales;

import java.util.Scanner;


public class Ejercicio_9 {


    public static void main(String[] args) {
        
         // Pedimos el año al usuario
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce un año:");
        int anio = sc.nextInt();

        // Comprobamos si el año es bisiesto
        boolean esBisiesto = false;

        if (anio % 4 == 0) {
            if (anio % 100 != 0 || anio % 400 == 0) {
                esBisiesto = true;
            }
        }

        // Mostramos el resultado
        if (esBisiesto) {
            System.out.println(anio + " es un año bisiesto");
        }
        else {
            System.out.println(anio + " no es un año bisiesto");
        }

        sc.close();    
    }
}
