package Condicionales;

import java.util.Scanner;


public class Ejercicio_16 {


    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in); // crear un objeto Scanner para leer la entrada del usuario
        
        // Definir los costos por zona
         double COSTO_ZONA_1 = 24.00;
         double COSTO_ZONA_2 = 20.00;
         double COSTO_ZONA_3 = 21.00;
         double COSTO_ZONA_4 = 10.00;
         double COSTO_ZONA_5 = 18.00;
        
        System.out.print("Ingrese el peso del paquete en kilogramos: ");
        double peso = sc.nextDouble(); // leer el peso del paquete
        
        // Verificar si el paquete cumple con el requisito de peso
        if (peso > 5) {
            System.out.println("Lo sentimos, no transportamos paquetes con un peso superior a 5kg.");
        } else {
            System.out.print("Ingrese la zona de destino (1-5):\n1. América del Norte\n2. América Central\n3. América del Sur\n4. Europa\n5. Asia\n");
            int zona = sc.nextInt(); // leer la zona de destino
            
            double costoPorKilo; // variable para almacenar el costo por kilogramo de la zona
            
            // Asignar el costo por kilogramo de acuerdo a la zona seleccionada
            switch (zona) {
                case 1:
                    costoPorKilo = COSTO_ZONA_1;
                    break;
                case 2:
                    costoPorKilo = COSTO_ZONA_2;
                    break;
                case 3:
                    costoPorKilo = COSTO_ZONA_3;
                    break;
                case 4:
                    costoPorKilo = COSTO_ZONA_4;
                    break;
                case 5:
                    costoPorKilo = COSTO_ZONA_5;
                    break;
                default:
                    System.out.println("Zona inválida. Por favor ingrese una zona del 1 al 5.");
                    return;
            }
            
            // Calcular el costo total del envío
            double costoTotal = costoPorKilo * peso;
            
            // Mostrar el costo total del envío
            System.out.println("El costo total del envío es de " + costoTotal + " euros.");
        }
        sc.close();
    }
}
