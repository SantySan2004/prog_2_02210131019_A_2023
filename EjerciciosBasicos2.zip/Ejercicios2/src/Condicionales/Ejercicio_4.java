package Condicionales;

import java.util.Scanner;


public class Ejercicio_4 {


    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in); 
        
        System.out.print("Ingrese una palabra: ");
        String palabra = entrada.nextLine();
        
        // Inicializamos una variable booleana que indicará si la palabra contiene una letra mayúscula
        boolean contieneMayuscula = false; 
        
        for (int i = 0; i < palabra.length(); i++) { 
            char letra = palabra.charAt(i); 
            
            if (Character.isUpperCase(letra)) {
                // Si encontramos una letra mayúscula, cambiamos el valor de la variable a true y salimos del ciclo for
                contieneMayuscula = true; 
            }
        }
        
        if (contieneMayuscula) {
            System.out.println("La palabra contiene al menos una letra mayúscula.");
        } else {
            System.out.println("La palabra no contiene letras mayúsculas.");
        }
    }
}
