package Condicionales;

import java.util.Scanner;


public class Ejercicio_11 {


    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el número de alumnos:");
        int numAlumnos = sc.nextInt();

        double costoAlumno, costoTotal;

        if (numAlumnos >= 100) {
            costoAlumno = 65.0;
            costoTotal = numAlumnos * costoAlumno;
        } else if (numAlumnos >= 50 && numAlumnos <= 99) {
            costoAlumno = 70.0;
            costoTotal = numAlumnos * costoAlumno;
        } else if (numAlumnos >= 30 && numAlumnos <= 49) {
            costoAlumno = 95.0;
            costoTotal = numAlumnos * costoAlumno;
        } else {
            costoTotal = 4000.0;
            costoAlumno = costoTotal / numAlumnos;
        }

        System.out.println("El costo total del viaje es: " + costoTotal + " euros");
        System.out.println("El costo por alumno es: " + costoAlumno + " euros");

        sc.close();
    }
}
