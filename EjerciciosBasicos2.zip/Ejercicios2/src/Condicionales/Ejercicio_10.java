package Condicionales;

import java.util.Scanner;


public class Ejercicio_10 {


    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el tipo de uva (A o B):");
        String tipo = sc.next().toUpperCase();
        System.out.println("Ingrese el tamaño de la uva (1 o 2):");
        int tamano = sc.nextInt();
        System.out.println("Ingrese la cantidad de kilos de uva entregados:");
        double kilos = sc.nextDouble();

        // Definimos el precio inicial por kilo según el tipo de uva
        double precioInicial = 0.0;
        if (tipo.equals("A")) {
            precioInicial = 0.5; // Precio inicial para uvas tipo A
        }
        else if (tipo.equals("B")) {
            precioInicial = 0.3; // Precio inicial para uvas tipo B
        }
        else {
            System.out.println("Tipo de uva inválido.");
            System.exit(0);
        }

        // Ajustamos el precio según el tamaño de la uva
        if (tamano == 1) {
            if (tipo.equals("A")) {
                precioInicial += 0.2;
            }
            else {
                precioInicial -= 0.3;
            }
        }
        else if (tamano == 2) {
            if (tipo.equals("A")) {
                precioInicial += 0.3;
            }
            else {
                precioInicial -= 0.5;
            }
        }
        else {
            System.out.println("Tamaño de uva inválido.");
            System.exit(0);
        }

        // Calculamos el precio total del embarque
        double precioTotal = kilos * precioInicial;

        // Mostramos el resultado
        System.out.println("El precio total del embarque es: " + precioTotal);

        sc.close();
    }
}
