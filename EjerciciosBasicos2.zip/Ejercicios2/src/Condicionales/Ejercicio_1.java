package Condicionales;

import java.util.Scanner;


public class Ejercicio_1 {


    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        System.out.print("Ingrese el primer número: ");
        int num1 = entrada.nextInt();
        
        System.out.print("Ingrese el segundo número: ");
        int num2 = entrada.nextInt();
        
        if (num1 > num2) {
            System.out.println(num1 + " es mayor que " + num2);
        } else if (num2 > num1) {
            System.out.println(num2 + " es mayor que " + num1);
        } else {
            System.out.println("Los números son iguales.");
        }
    }
}
