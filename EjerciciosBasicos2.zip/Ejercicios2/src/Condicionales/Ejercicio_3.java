package Condicionales;

import java.util.Scanner;


public class Ejercicio_3 {


    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in); 
        
        System.out.print("Ingrese el dividendo: ");
        double dividendo = entrada.nextDouble(); 
        
        System.out.print("Ingrese el divisor: ");
        double divisor = entrada.nextDouble();
        
        // Comprobamos si el divisor es cero
        if (divisor == 0) { 
            System.out.println("Error: no se puede dividir por cero.");
        } else {
            double resultado = dividendo / divisor; 
            System.out.println("El resultado de la división es: " + resultado);
        }
    }
}
