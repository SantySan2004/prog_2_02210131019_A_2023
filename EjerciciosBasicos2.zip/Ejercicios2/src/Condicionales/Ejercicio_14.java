package Condicionales;

import java.util.Scanner;


public class Ejercicio_14 {


    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in); // Crear objeto Scanner para leer entrada del usuario
        
        System.out.print("Introduce el número del día de la semana (del 1 al 7): ");
        int numDia = entrada.nextInt(); // Leer número del día de la semana
        
        // Utilizar una estructura switch para determinar el día correspondiente al número ingresado
        switch (numDia) {
            case 1:
                System.out.println("Lunes");
                break;
            case 2:
                System.out.println("Martes");
                break;
            case 3:
                System.out.println("Miércoles");
                break;
            case 4:
                System.out.println("Jueves");
                break;
            case 5:
                System.out.println("Viernes");
                break;
            case 6:
                System.out.println("Sábado");
                break;
            case 7:
                System.out.println("Domingo");
                break;
            default:
                System.out.println("ERROR: número incorrecto");
        }
    }
}
