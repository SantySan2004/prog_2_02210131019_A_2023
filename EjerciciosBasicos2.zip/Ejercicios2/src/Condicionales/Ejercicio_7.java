package Condicionales;

import java.util.Scanner;


public class Ejercicio_7 {


    public static void main(String[] args) {
        // Pedimos los puntos centrales y los radios de las dos circunferencias
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce los puntos centrales de las dos circunferencias (x1, y1), (x2, y2) y los radios (r1, r2):");
        double x1 = sc.nextDouble();
        double y1 = sc.nextDouble();
        double r1 = sc.nextDouble();
        double x2 = sc.nextDouble();
        double y2 = sc.nextDouble();
        double r2 = sc.nextDouble();

        // Calculamos la distancia entre los puntos centrales de las dos circunferencias
        double distanciaCentros = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));

        // Caso 1: Circunferencias exteriores
        if (distanciaCentros > r1 + r2) {
            System.out.println("Las circunferencias son exteriores");
        }

        // Caso 2: Circunferencias tangentes exteriores
        else if (distanciaCentros == r1 + r2) {
            System.out.println("Las circunferencias son tangentes exteriores");
        }

        // Caso 3: Circunferencias secantes
        else if (distanciaCentros < r1 + r2 && distanciaCentros > Math.abs(r2 - r1)) {
            System.out.println("Las circunferencias son secantes");
        }

        // Caso 4: Circunferencias tangentes interiores
        else if (distanciaCentros == Math.abs(r2 - r1)) {
            System.out.println("Las circunferencias son tangentes interiores");
        }

        // Caso 5: Circunferencias interiores
        else if (distanciaCentros < Math.abs(r2 - r1)) {
            System.out.println("Las circunferencias son interiores");
        }

        // Caso 6: Circunferencias concéntricas
        else if (distanciaCentros == 0 && r1 == r2) {
            System.out.println("Las circunferencias son concéntricas");
        }

        // Caso no válido: Los datos introducidos no corresponden a dos circunferencias
        else {
            System.out.println("Los datos introducidos no corresponden a dos circunferencias");
        }

        sc.close();
    }
    
}
