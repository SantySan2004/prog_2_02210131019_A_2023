package Condicionales;

import java.util.Scanner;


public class Ejercicio_5 {


    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.print("Ingrese la base: ");
        double base = entrada.nextDouble(); 

        System.out.print("Ingrese el exponente: ");
        int exponente = entrada.nextInt(); 
        
        // Inicializamos una variable para almacenar el resultado con valor 1 por si el exponente es 0
        double resultado = 1; 

        // Si el exponente es positivo, multiplicamos la base por sí misma exponente veces
        if (exponente > 0) {
            for (int i = 1; i <= exponente; i++) {
                resultado *= base;
            }
        }
        
        // Si el exponente es negativo, multiplicamos 1 por la base inversa (1/base) exponente veces
        else if (exponente < 0) {
            for (int i = 1; i <= -exponente; i++) {
                resultado *= (1/base);
            }
        }
        // Si el exponente es 0, el resultado es 1
        else {
            resultado = 1;
        }
        System.out.println("El resultado es: " + resultado);
    }
}
