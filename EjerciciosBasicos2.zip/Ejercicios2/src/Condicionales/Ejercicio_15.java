package Condicionales;

import java.util.Scanner;


public class Ejercicio_15 {


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Pedimos al usuario que ingrese un número entre 1 y 12
        System.out.print("Ingrese un número entre 1 y 12: ");
        int mes = sc.nextInt();

        // Utilizamos un switch para comparar el número ingresado con cada mes del año
        switch (mes) {
            case 1: // Enero
            case 3: // Marzo
            case 5: // Mayo
            case 7: // Julio
            case 8: // Agosto
            case 10: // Octubre
            case 12: // Diciembre
                System.out.println("El mes tiene 31 días");
                break;
            case 4: // Abril
            case 6: // Junio
            case 9: // Septiembre
            case 11: // Noviembre
                System.out.println("El mes tiene 30 días");
                break;
            case 2: // Febrero
                System.out.println("El mes tiene 28 o 29 días, dependiendo del año");
                break;
            default: // Si el número ingresado no está entre 1 y 12
                System.out.println("Error: número ingresado incorrecto");
                break;
        }
    }
}
