package Condicionales;

import java.util.Scanner;


public class Ejercicio_8 {


    public static void main(String[] args) {
        // Pedimos los tamaños de los lados del triángulo
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce los tamaños de los lados del triángulo:");
        double lado1 = sc.nextDouble();
        double lado2 = sc.nextDouble();
        double lado3 = sc.nextDouble();

        // Comprobamos si los tamaños introducidos corresponden a un triángulo
        if (lado1 + lado2 > lado3 && lado2 + lado3 > lado1 && lado1 + lado3 > lado2) {

            // Comprobamos si el triángulo es rectángulo
            if (lado1 == Math.sqrt(lado2*lado2 + lado3*lado3) || lado2 == Math.sqrt(lado1*lado1 + lado3*lado3) || lado3 == Math.sqrt(lado1*lado1 + lado2*lado2)) {
                System.out.println("El triángulo es rectángulo");
            }

            // Comprobamos si el triángulo es isósceles o equilátero
            else if (lado1 == lado2 && lado1 == lado3) {
                System.out.println("El triángulo es equilátero");
            }
            else if (lado1 == lado2 || lado1 == lado3 || lado2 == lado3) {
                System.out.println("El triángulo es isósceles");
            }

            // Si no es rectángulo, isósceles ni equilátero, entonces es escaleno
            else {
                System.out.println("El triángulo es escaleno");
            }
        }

        // Si los tamaños introducidos no corresponden a un triángulo
        else {
            System.out.println("Los tamaños introducidos no corresponden a un triángulo");
        }
        sc.close();
    }
}
