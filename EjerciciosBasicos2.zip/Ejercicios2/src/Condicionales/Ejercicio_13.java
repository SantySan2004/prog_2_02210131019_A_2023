package Condicionales;

import java.util.Scanner;


public class Ejercicio_13 {


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] opuestos = {6, 5, 4, 3, 2, 1}; // Array con los valores opuestos
        System.out.print("Introduce el resultado obtenido al lanzar el dado: ");
        int resultado = sc.nextInt();

        if (resultado < 1 || resultado > 6) { // Comprobamos si el valor está en el rango correcto
            System.out.println("ERROR: número incorrecto");
        } else {
            int opuesto = opuestos[resultado-1]; // Obtenemos el valor opuesto del array
            System.out.println("El número opuesto al " + resultado + " es " + opuesto);
        }
    }
}
