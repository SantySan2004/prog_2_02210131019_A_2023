package ejerciciosbasicos_1;

import java.util.Scanner;


public class EjerciciosBasicos_8 {

    public static void main(String[] args) {

        // Definir el sueldo base y la tasa de comisión
        double sueldoBase = 1000000.0;
        double tasaComision = 0.1;

        Scanner entrada = new Scanner(System.in);

        // Pedir al usuario que ingrese las ventas del mes
        System.out.print("Por favor ingrese la venta 1 del mes: ");
        double venta1 = entrada.nextDouble();

        System.out.print("Por favor ingrese la venta 2 del mes: ");
        double venta2 = entrada.nextDouble();

        System.out.print("Por favor ingrese la venta 3 del mes: ");
        double venta3 = entrada.nextDouble();

        // Calcular la comisión por las tres ventas
        double comision = (venta1 + venta2 + venta3) * tasaComision;

        // Calcular el salario total del mes
        double salarioTotal = sueldoBase + comision;

        // Mostrar el resultado al usuario
        System.out.println("El vendedor recibirá $" + comision + " por concepto de comisiones por las tres ventas que realizó en el mes.");
        System.out.println("El salario total del mes será de $" + salarioTotal + ".");
    }
}
