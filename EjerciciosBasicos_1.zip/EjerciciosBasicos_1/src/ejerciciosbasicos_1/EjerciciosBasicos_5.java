package ejerciciosbasicos_1;

import java.util.Scanner;


public class EjerciciosBasicos_5 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        // Pedir al usuario que ingrese la temperatura en Fahrenheit
        System.out.print("Por favor ingrese la temperatura en grados Fahrenheit: ");
        double temperaturaF = entrada.nextDouble();

        // Calcular la temperatura en grados Celsius
        double temperaturaC = (temperaturaF - 32) * 5 / 9;

        // Mostrar la temperatura en grados Celsius
        System.out.println("La temperatura en grados Celsius es: " + temperaturaC);
    }
}
