package ejerciciosbasicos_1;

import java.util.Scanner;


public class EjerciciosBasicos_11 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        // Pedir al usuario que ingrese los dos números
        System.out.print("Por favor ingrese el primer número: ");
        double num1 = entrada.nextDouble();

        System.out.print("Por favor ingrese el segundo número: ");
        double num2 = entrada.nextDouble();

        // Calcular la distancia entre los dos números
        double distancia = Math.abs(num2 - num1);

        // Mostrar la distancia al usuario
        System.out.println("La distancia entre " + num1 + " y " + num2 + " es: " + distancia); 
    }
}
