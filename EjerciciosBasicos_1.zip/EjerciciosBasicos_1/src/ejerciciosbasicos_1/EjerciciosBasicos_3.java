package ejerciciosbasicos_1;

import java.util.Scanner;


public class EjerciciosBasicos_3 {

    public static void main(String[] args) {

      Scanner entrada = new Scanner(System.in);
      
      // Pedir al usuario que ingrese la longitud del primer cateto
      System.out.print("Por favor ingrese la longitud del primer cateto: ");
      
      // Leer la longitud del primer cateto
      double cateto1 = entrada.nextDouble();
      
      // Pedir al usuario que ingrese la longitud del segundo cateto
      System.out.print("Por favor ingrese la longitud del segundo cateto: ");
      
      // Leer la longitud del segundo cateto
      double cateto2 = entrada.nextDouble();
      
      // Calcular la hipotenusa del triángulo rectángulo
      double hipotenusa = Math.sqrt(cateto1 * cateto1 + cateto2 * cateto2);
      
      System.out.println("La hipotenusa del triángulo rectángulo es: " + hipotenusa);
    }
}
