package ejerciciosbasicos_1;

import java.util.Scanner;


public class EjerciciosBasicos_15 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Solicitamos los valores de A y B al usuario
        System.out.print("Introduce el valor de A: ");
        int A = sc.nextInt();
        System.out.print("Introduce el valor de B: ");
        int B = sc.nextInt();

        // Intercambiamos los valores de A y B utilizando una variable auxiliar
        int aux = A;
        A = B;
        B = aux;

        // Mostramos los valores finales de A y B
        System.out.println("El valor de A al final es: " + A);
        System.out.println("El valor de B al final es: " + B);
      
    }
    
}
