package ejerciciosbasicos_1;

import java.util.Scanner;


public class EjerciciosBasicos_18 {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Introduce tu nombre: ");
        String nombre = sc.nextLine();
        
        System.out.print("Introduce tu primer apellido: ");
        String apellido1 = sc.nextLine();
        
        System.out.print("Introduce tu segundo apellido: ");
        String apellido2 = sc.nextLine();

        // Obtener las iniciales
        char inicialNombre = nombre.charAt(0);
        char inicialApellido1 = apellido1.charAt(0);
        char inicialApellido2 = apellido2.charAt(0);

        System.out.println("Tus iniciales son: " + inicialNombre + inicialApellido1 + inicialApellido2);
    }
}
