package ejerciciosbasicos_1;

import java.util.Scanner;

public class EjerciciosBasicos_1 {

    public static void main(String[] args) {
      Scanner entrada = new Scanner(System.in);
      
      System.out.print("Por favor ingrese su nombre: ");
      
      String nombre = entrada.nextLine();

      System.out.println("¡Hola, " + nombre + "! Bienvenido.");
    }
    
}
