package ejerciciosbasicos_1;

import java.util.Scanner;


public class EjerciciosBasicos_20 {

    public static void main(String[] args) {

        // Definir las constantes correspondientes al valor de cada moneda
        final int DOS_EUROS = 200;
        final int UN_EURO = 100;
        final int CINCUENTA_CENTIMOS = 50;
        final int VEINTE_CENTIMOS = 20;
        final int DIEZ_CENTIMOS = 10;

        // Pedir al usuario la cantidad de monedas de cada tipo
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Introduce la cantidad de monedas de 2 euros: ");
        int dosEuros = sc.nextInt();
        
        System.out.print("Introduce la cantidad de monedas de 1 euro: ");
        int unEuro = sc.nextInt();
        
        System.out.print("Introduce la cantidad de monedas de 50 céntimos: ");
        int cincuentaCentimos = sc.nextInt();
        
        System.out.print("Introduce la cantidad de monedas de 20 céntimos: ");
        int veinteCentimos = sc.nextInt();
        
        System.out.print("Introduce la cantidad de monedas de 10 céntimos: ");
        int diezCentimos = sc.nextInt();


        int totalEuros = dosEuros * DOS_EUROS + unEuro * UN_EURO + cincuentaCentimos * CINCUENTA_CENTIMOS + veinteCentimos * VEINTE_CENTIMOS + diezCentimos * DIEZ_CENTIMOS;
        int euros = totalEuros / 100;
        int centimos = totalEuros % 100;

        // Mostrar el resultado
        System.out.println("Tienes " + euros + " euros y " + centimos + " céntimos.");
    }
}
