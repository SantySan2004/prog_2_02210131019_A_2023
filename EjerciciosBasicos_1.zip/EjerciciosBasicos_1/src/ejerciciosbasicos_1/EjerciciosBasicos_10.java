package ejerciciosbasicos_1;

import java.util.Scanner;


public class EjerciciosBasicos_10 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        // Pedir al usuario que ingrese las calificaciones parciales
        System.out.print("Por favor ingrese la calificación del primer parcial: ");
        double calificacion1 = entrada.nextDouble();

        System.out.print("Por favor ingrese la calificación del segundo parcial: ");
        double calificacion2 = entrada.nextDouble();

        System.out.print("Por favor ingrese la calificación del tercer parcial: ");
        double calificacion3 = entrada.nextDouble();

        // Pedir al usuario que ingrese la calificación del examen final
        System.out.print("Por favor ingrese la calificación del examen final: ");
        double calificacionFinal = entrada.nextDouble();

        // Pedir al usuario que ingrese la calificación del trabajo final
        System.out.print("Por favor ingrese la calificación del trabajo final: ");
        double calificacionTrabajo = entrada.nextDouble();

        // Calcular la calificación final
        double promedioParciales = (calificacion1 + calificacion2 + calificacion3) / 3;
        double calificacionFinalTotal = promedioParciales * 0.55 + calificacionFinal * 0.3 + calificacionTrabajo * 0.15;

        // Mostrar la calificación final al usuario
        System.out.println("La calificación final del alumno es: " + calificacionFinalTotal);
    }
}
