package ejerciciosbasicos_1;

import java.util.Scanner;


public class EjerciciosBasicos_4 {

    public static void main(String[] args) {
      Scanner entrada = new Scanner(System.in);
      
      // Pedir al usuario que ingrese el primer número
      System.out.print("Por favor ingrese el primer número: ");
      
      double numero1 = entrada.nextDouble();
      
      System.out.print("Por favor ingrese el segundo número: ");
      
      double numero2 = entrada.nextDouble();
      
      // Calcular la suma, resta, división y multiplicación de los dos números
      double suma = numero1 + numero2;
      double resta = numero1 - numero2;
      double division = numero1 / numero2;
      double multiplicacion = numero1 * numero2;
      
      System.out.println("La suma de " + numero1 + " y " + numero2 + " es: " + suma);
      System.out.println("La resta de " + numero1 + " y " + numero2 + " es: " + resta);
      System.out.println("La división de " + numero1 + " entre " + numero2 + " es: " + division);
      System.out.println("La multiplicación de " + numero1 + " y " + numero2 + " es: " + multiplicacion);
    }
}
