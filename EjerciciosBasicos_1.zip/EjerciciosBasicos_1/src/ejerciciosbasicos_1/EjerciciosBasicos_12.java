package ejerciciosbasicos_1;

import java.util.Scanner;


public class EjerciciosBasicos_12 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        // Pedir al usuario que ingrese los valores de x1, y1, x2 e y2
        System.out.print("Por favor ingrese el valor de x1: ");
        double x1 = entrada.nextDouble();

        System.out.print("Por favor ingrese el valor de y1: ");
        double y1 = entrada.nextDouble();

        System.out.print("Por favor ingrese el valor de x2: ");
        double x2 = entrada.nextDouble();

        System.out.print("Por favor ingrese el valor de y2: ");
        double y2 = entrada.nextDouble();

        // Calcular la distancia entre los dos puntos
        double dx = x2 - x1;
        double dy = y2 - y1;
        double distancia = Math.sqrt(dx * dx + dy * dy);
        
        System.out.println("La distancia entre los puntos (" + x1 + "," + y1 + ") y (" + x2 + "," + y2 + ") es: " + distancia);
      
    }
    
}
