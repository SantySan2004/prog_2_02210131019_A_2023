package ejerciciosbasicos_1;

import java.util.Scanner;


public class EjerciciosBasicos_9 {

    public static void main(String[] args) {
        
        // Definir la tasa de descuento
        double tasaDescuento = 0.15;

        Scanner entrada = new Scanner(System.in);

        // Pedir al usuario que ingrese el total de la compra
        System.out.print("Por favor ingrese el total de la compra: ");
        double totalCompra = entrada.nextDouble();

        // Calcular el descuento y el total a pagar
        double descuento = totalCompra * tasaDescuento;
        double totalPagar = totalCompra - descuento;

        System.out.println("El descuento sobre el total de la compra es de $" + descuento + ".");
        System.out.println("El total a pagar es de $" + totalPagar + ".");
      
    }
}
