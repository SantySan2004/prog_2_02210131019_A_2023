package ejerciciosbasicos_1;

import java.util.Scanner;


public class EjerciciosBasicos_6 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        // Pedir al usuario que ingrese los tres números
        System.out.print("Por favor ingrese el primer número: ");
        double numero1 = entrada.nextDouble();

        System.out.print("Por favor ingrese el segundo número: ");
        double numero2 = entrada.nextDouble();

        System.out.print("Por favor ingrese el tercer número: ");
        double numero3 = entrada.nextDouble();

        // Calcular la media de los tres números
        double media = (numero1 + numero2 + numero3) / 3;

        System.out.println("La media de " + numero1 + ", " + numero2 + " y " + numero3 + " es: " + media);
    }
}
