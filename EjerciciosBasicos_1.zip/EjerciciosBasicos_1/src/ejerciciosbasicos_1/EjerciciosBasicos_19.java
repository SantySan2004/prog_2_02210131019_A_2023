package ejerciciosbasicos_1;

import java.util.Scanner;


public class EjerciciosBasicos_19 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Pedir al usuario el número de respuestas correctas, incorrectas y no contestadas
        System.out.print("Ingrese el número de respuestas correctas: ");
        int correctas = sc.nextInt();

        System.out.print("Ingrese el número de respuestas incorrectas: ");
        int incorrectas = sc.nextInt();

        System.out.print("Ingrese el número de respuestas no contestadas: ");
        int noContestadas = sc.nextInt();

        // Calcular la nota final
        int notaFinal = correctas * 5 - incorrectas;

        // Mostrar la nota final por pantalla
        System.out.println("La nota final es: " + notaFinal);
    }
}
