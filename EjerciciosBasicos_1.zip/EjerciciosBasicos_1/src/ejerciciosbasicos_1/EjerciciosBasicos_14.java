package ejerciciosbasicos_1;

import java.util.Scanner;


public class EjerciciosBasicos_14 {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        // Solicitamos el número al usuario
        System.out.print("Introduce un número de dos cifras: ");
        int num = sc.nextInt();

        // Obtenemos las unidades y las decenas del número
        int unidades = num % 10;
        int decenas = num / 10;

        // Invertimos el número
        int numInvertido = (unidades * 10) + decenas;

        // Mostramos el número invertido por pantalla
        System.out.println("El número invertido es: " + numInvertido);
    }
}
