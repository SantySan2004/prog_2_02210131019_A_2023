package ejerciciosbasicos_1;

import java.util.Scanner;


public class EjerciciosBasicos_7 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.print("Por favor ingrese la cantidad de minutos: ");
        int minutos = entrada.nextInt();

        // Calcular la cantidad de horas y minutos equivalentes
        int horas = minutos / 60;
        int minutosRestantes = minutos % 60;

        System.out.println(minutos + " minutos equivale a " + horas + " horas y " + minutosRestantes + " minutos.");
    }
}
