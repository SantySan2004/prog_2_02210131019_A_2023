package ejerciciosbasicos_1;

import java.util.Scanner;


public class EjerciciosBasicos_13 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        
        System.out.print("Introduce un número: ");
        double num = sc.nextDouble();
        
        double raizCuadrada = Math.sqrt(num);
        double raizCubica = Math.cbrt(num);
        
        System.out.println("La raíz cuadrada de " + num + " es " + raizCuadrada);
        System.out.println("La raíz cúbica de " + num + " es " + raizCubica);
      
    }
}
