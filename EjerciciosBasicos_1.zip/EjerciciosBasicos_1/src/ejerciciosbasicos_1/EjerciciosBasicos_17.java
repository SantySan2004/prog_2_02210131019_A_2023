package ejerciciosbasicos_1;

import java.util.Scanner;


public class EjerciciosBasicos_17 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        
        System.out.print("Introduzca la hora de salida (HH MM SS): ");
        int horaSalida = sc.nextInt();
        int minSalida = sc.nextInt();
        int segSalida = sc.nextInt();
        
        System.out.print("Introduzca el tiempo de viaje en segundos: ");
        int tiempoViaje = sc.nextInt();
        
        int tiempoLlegadaSeg = horaSalida*3600 + minSalida*60 + segSalida + tiempoViaje;
        int horaLlegada = tiempoLlegadaSeg / 3600;
        int minLlegada = (tiempoLlegadaSeg % 3600) / 60;
        int segLlegada = tiempoLlegadaSeg % 60;
        
        System.out.println("Hora de llegada: " + horaLlegada + ":" + minLlegada + ":" + segLlegada); 
    }
}
