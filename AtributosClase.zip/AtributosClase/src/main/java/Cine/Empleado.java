/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Cine;

import java.util.Date;

/**
 *
 * @author LabSispc15
 */
public class Empleado {
    
    private String Nombre;
    private String Apellido;
    private String Genero;
    private Date FechaDeNacimiento;
    private String LugarDeNacimiento;
    private String Nacionalidad;
    private String Direccion;
    private String Numero;
    private String Correo;
    private String PuestoDeTrabajo;
    private String Salario;
    private String Horario;

    public Empleado(String Nombre, String Apellido, String Genero, Date FechaDeNacimiento, String LugarDeNacimiento, String Nacionalidad, String Direccion, String Numero, String Correo, String PuestoDeTrabajo, String Salario, String Horario) {
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.Genero = Genero;
        this.FechaDeNacimiento = FechaDeNacimiento;
        this.LugarDeNacimiento = LugarDeNacimiento;
        this.Nacionalidad = Nacionalidad;
        this.Direccion = Direccion;
        this.Numero = Numero;
        this.Correo = Correo;
        this.PuestoDeTrabajo = PuestoDeTrabajo;
        this.Salario = Salario;
        this.Horario = Horario;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public String getGenero() {
        return Genero;
    }

    public void setGenero(String Genero) {
        this.Genero = Genero;
    }

    public Date getFechaDeNacimiento() {
        return FechaDeNacimiento;
    }

    public void setFechaDeNacimiento(Date FechaDeNacimiento) {
        this.FechaDeNacimiento = FechaDeNacimiento;
    }

    public String getLugarDeNacimiento() {
        return LugarDeNacimiento;
    }

    public void setLugarDeNacimiento(String LugarDeNacimiento) {
        this.LugarDeNacimiento = LugarDeNacimiento;
    }

    public String getNacionalidad() {
        return Nacionalidad;
    }

    public void setNacionalidad(String Nacionalidad) {
        this.Nacionalidad = Nacionalidad;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public String getNumero() {
        return Numero;
    }

    public void setNumero(String Numero) {
        this.Numero = Numero;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String Correo) {
        this.Correo = Correo;
    }

    public String getPuestoDeTrabajo() {
        return PuestoDeTrabajo;
    }

    public void setPuestoDeTrabajo(String PuestoDeTrabajo) {
        this.PuestoDeTrabajo = PuestoDeTrabajo;
    }

    public String getSalario() {
        return Salario;
    }

    public void setSalario(String Salario) {
        this.Salario = Salario;
    }

    public String getHorario() {
        return Horario;
    }

    public void setHorario(String Horario) {
        this.Horario = Horario;
    }
    
    
    
      
            
}
