/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Cine;

/**
 *
 * @author LabSispc15
 */
public class SalasDeCine {
    
    private String NombreDeCine;
    private String CalidadDeImagen;
    private String Ubicacion;
    private String CalidadDeSonido;
    private int NumeroDeSalas;
    private int ProyeccionesDiarias;
    private int TamañoDeSalas;
    private int horario;
    private int CapacidadDeLasSalas;
    private int PrecioDeEntradas;
    private String TipoDePantalla;

    public SalasDeCine(String NombreDeCine, String CalidadDeImagen, String Ubicacion, String CalidadDeSonido, int NumeroDeSalas, int ProyeccionesDiarias, int TamañoDeSalas, int horario, int CapacidadDeLasSalas, int PrecioDeEntradas, String TipoDePantalla) {
        this.NombreDeCine = NombreDeCine;
        this.CalidadDeImagen = CalidadDeImagen;
        this.Ubicacion = Ubicacion;
        this.CalidadDeSonido = CalidadDeSonido;
        this.NumeroDeSalas = NumeroDeSalas;
        this.ProyeccionesDiarias = ProyeccionesDiarias;
        this.TamañoDeSalas = TamañoDeSalas;
        this.horario = horario;
        this.CapacidadDeLasSalas = CapacidadDeLasSalas;
        this.PrecioDeEntradas = PrecioDeEntradas;
        this.TipoDePantalla = TipoDePantalla;
    }

    public String getNombreDeCine() {
        return NombreDeCine;
    }

    public void setNombreDeCine(String NombreDeCine) {
        this.NombreDeCine = NombreDeCine;
    }

    public String getCalidadDeImagen() {
        return CalidadDeImagen;
    }

    public void setCalidadDeImagen(String CalidadDeImagen) {
        this.CalidadDeImagen = CalidadDeImagen;
    }

    public String getUbicacion() {
        return Ubicacion;
    }

    public void setUbicacion(String Ubicacion) {
        this.Ubicacion = Ubicacion;
    }

    public String getCalidadDeSonido() {
        return CalidadDeSonido;
    }

    public void setCalidadDeSonido(String CalidadDeSonido) {
        this.CalidadDeSonido = CalidadDeSonido;
    }

    public int getNumeroDeSalas() {
        return NumeroDeSalas;
    }

    public void setNumeroDeSalas(int NumeroDeSalas) {
        this.NumeroDeSalas = NumeroDeSalas;
    }

    public int getProyeccionesDiarias() {
        return ProyeccionesDiarias;
    }

    public void setProyeccionesDiarias(int ProyeccionesDiarias) {
        this.ProyeccionesDiarias = ProyeccionesDiarias;
    }

    public int getTamañoDeSalas() {
        return TamañoDeSalas;
    }

    public void setTamañoDeSalas(int TamañoDeSalas) {
        this.TamañoDeSalas = TamañoDeSalas;
    }

    public int getHorario() {
        return horario;
    }

    public void setHorario(int horario) {
        this.horario = horario;
    }

    public int getCapacidadDeLasSalas() {
        return CapacidadDeLasSalas;
    }

    public void setCapacidadDeLasSalas(int CapacidadDeLasSalas) {
        this.CapacidadDeLasSalas = CapacidadDeLasSalas;
    }

    public int getPrecioDeEntradas() {
        return PrecioDeEntradas;
    }

    public void setPrecioDeEntradas(int PrecioDeEntradas) {
        this.PrecioDeEntradas = PrecioDeEntradas;
    }

    public String getTipoDePantalla() {
        return TipoDePantalla;
    }

    public void setTipoDePantalla(String TipoDePantalla) {
        this.TipoDePantalla = TipoDePantalla;
    }
    
    
}
