/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package supermercado;

/**
 *
 * @author LabSispc15
 */
public class producto {
   
    private String TipoDeProducto;
    private int Codigo;
    private int Precio;
    private int Cantidad;
    private String Funcionalidad;
    private String Marca;
    private String Modelo;
    private String Tamaño;
    private int Peso;
    private String Material;
    private String Color;
    private float Durabilidad;
    private String Garantia;
    private String Instruccion;
    private Double Disponibilidad;
    private int fechadenacimiento;

    public producto(String TipoDeProducto, int Codigo, int Precio, int Cantidad, String Funcionalidad, String Marca, String Modelo, String Tamaño, int Peso, String Material, String Color, float Durabilidad, String Garantia, String Instruccion, Double Disponibilidad, int fechadenacimiento) {
        this.TipoDeProducto = TipoDeProducto;
        this.Codigo = Codigo;
        this.Precio = Precio;
        this.Cantidad = Cantidad;
        this.Funcionalidad = Funcionalidad;
        this.Marca = Marca;
        this.Modelo = Modelo;
        this.Tamaño = Tamaño;
        this.Peso = Peso;
        this.Material = Material;
        this.Color = Color;
        this.Durabilidad = Durabilidad;
        this.Garantia = Garantia;
        this.Instruccion = Instruccion;
        this.Disponibilidad = Disponibilidad;
        this.fechadenacimiento = fechadenacimiento;
    }

    public String getTipoDeProducto() {
        return TipoDeProducto;
    }

    public void setTipoDeProducto(String TipoDeProducto) {
        this.TipoDeProducto = TipoDeProducto;
    }

    public int getCodigo() {
        return Codigo;
    }

    public void setCodigo(int Codigo) {
        this.Codigo = Codigo;
    }

    public int getPrecio() {
        return Precio;
    }

    public void setPrecio(int Precio) {
        this.Precio = Precio;
    }

    public int getCantidad() {
        return Cantidad;
    }

    public void setCantidad(int Cantidad) {
        this.Cantidad = Cantidad;
    }

    public String getFuncionalidad() {
        return Funcionalidad;
    }

    public void setFuncionalidad(String Funcionalidad) {
        this.Funcionalidad = Funcionalidad;
    }

    public String getMarca() {
        return Marca;
    }

    public void setMarca(String Marca) {
        this.Marca = Marca;
    }

    public String getModelo() {
        return Modelo;
    }

    public void setModelo(String Modelo) {
        this.Modelo = Modelo;
    }

    public String getTamaño() {
        return Tamaño;
    }

    public void setTamaño(String Tamaño) {
        this.Tamaño = Tamaño;
    }

    public int getPeso() {
        return Peso;
    }

    public void setPeso(int Peso) {
        this.Peso = Peso;
    }

    public String getMaterial() {
        return Material;
    }

    public void setMaterial(String Material) {
        this.Material = Material;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }

    public float getDurabilidad() {
        return Durabilidad;
    }

    public void setDurabilidad(float Durabilidad) {
        this.Durabilidad = Durabilidad;
    }

    public String getGarantia() {
        return Garantia;
    }

    public void setGarantia(String Garantia) {
        this.Garantia = Garantia;
    }

    public String getInstruccion() {
        return Instruccion;
    }

    public void setInstruccion(String Instruccion) {
        this.Instruccion = Instruccion;
    }

    public Double getDisponibilidad() {
        return Disponibilidad;
    }

    public void setDisponibilidad(Double Disponibilidad) {
        this.Disponibilidad = Disponibilidad;
    }

    public int getFechadenacimiento() {
        return fechadenacimiento;
    }

    public void setFechadenacimiento(int fechadenacimiento) {
        this.fechadenacimiento = fechadenacimiento;
    }
    
    
    
}
