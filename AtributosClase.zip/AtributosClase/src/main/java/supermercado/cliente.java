/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package supermercado;

import java.util.Date;

/**
 *
 * @author LabSispc15
 */
public class cliente {

private String Nombre;
private String Apellido;
private String Genero;
private Date Fecha;
private String Direccion;
private int Numero;
private String Correo;
private String Informacion;
private String Historial;
private String Preferencia;
private String Sugerencia;
private String MetodosDePago;

    public cliente(String Nombre, String Apellido, String Genero, Date Fecha, String Direccion, int Numero, String Correo, String Informacion, String Historial, String Preferencia, String Sugerencia, String MetodosDePago) {
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.Genero = Genero;
        this.Fecha = Fecha;
        this.Direccion = Direccion;
        this.Numero = Numero;
        this.Correo = Correo;
        this.Informacion = Informacion;
        this.Historial = Historial;
        this.Preferencia = Preferencia;
        this.Sugerencia = Sugerencia;
        this.MetodosDePago = MetodosDePago;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public String getGenero() {
        return Genero;
    }

    public void setGenero(String Genero) {
        this.Genero = Genero;
    }

    public Date getFecha() {
        return Fecha;
    }

    public void setFecha(Date Fecha) {
        this.Fecha = Fecha;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public int getNumero() {
        return Numero;
    }

    public void setNumero(int Numero) {
        this.Numero = Numero;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String Correo) {
        this.Correo = Correo;
    }

    public String getInformacion() {
        return Informacion;
    }

    public void setInformacion(String Informacion) {
        this.Informacion = Informacion;
    }

    public String getHistorial() {
        return Historial;
    }

    public void setHistorial(String Historial) {
        this.Historial = Historial;
    }

    public String getPreferencia() {
        return Preferencia;
    }

    public void setPreferencia(String Preferencia) {
        this.Preferencia = Preferencia;
    }

    public String getSugerencia() {
        return Sugerencia;
    }

    public void setSugerencia(String Sugerencia) {
        this.Sugerencia = Sugerencia;
    }

    public String getMetodosDePago() {
        return MetodosDePago;
    }

    public void setMetodosDePago(String MetodosDePago) {
        this.MetodosDePago = MetodosDePago;
    }

    
    


}
