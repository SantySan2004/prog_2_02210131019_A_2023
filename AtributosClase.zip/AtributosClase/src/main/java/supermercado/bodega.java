/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package supermercado;

/**
 *
 * @author LabSispc15
 */
public class bodega {
    
    private String Nombre;
    private String Ubicacion;
    private int Tamaño;
    private int Capacidad;
    private String Temperatura;
    private String TipoDeMercado;
    private String NivelDeRiesgo;
    private String Seguridad;
    private String Accesibilidad;
    private String Tipo;
    private String Condiciones;

    public bodega(String Nombre, String Ubicacion, int Tamaño, int Capacidad, String Temperatura, String TipoDeMercado, String NivelDeRiesgo, String Seguridad, String Accesibilidad, String Tipo, String Condiciones) {
        this.Nombre = Nombre;
        this.Ubicacion = Ubicacion;
        this.Tamaño = Tamaño;
        this.Capacidad = Capacidad;
        this.Temperatura = Temperatura;
        this.TipoDeMercado = TipoDeMercado;
        this.NivelDeRiesgo = NivelDeRiesgo;
        this.Seguridad = Seguridad;
        this.Accesibilidad = Accesibilidad;
        this.Tipo = Tipo;
        this.Condiciones = Condiciones;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getUbicacion() {
        return Ubicacion;
    }

    public void setUbicacion(String Ubicacion) {
        this.Ubicacion = Ubicacion;
    }

    public int getTamaño() {
        return Tamaño;
    }

    public void setTamaño(int Tamaño) {
        this.Tamaño = Tamaño;
    }

    public int getCapacidad() {
        return Capacidad;
    }

    public void setCapacidad(int Capacidad) {
        this.Capacidad = Capacidad;
    }

    public String getTemperatura() {
        return Temperatura;
    }

    public void setTemperatura(String Temperatura) {
        this.Temperatura = Temperatura;
    }

    public String getTipoDeMercado() {
        return TipoDeMercado;
    }

    public void setTipoDeMercado(String TipoDeMercado) {
        this.TipoDeMercado = TipoDeMercado;
    }

    public String getNivelDeRiesgo() {
        return NivelDeRiesgo;
    }

    public void setNivelDeRiesgo(String NivelDeRiesgo) {
        this.NivelDeRiesgo = NivelDeRiesgo;
    }

    public String getSeguridad() {
        return Seguridad;
    }

    public void setSeguridad(String Seguridad) {
        this.Seguridad = Seguridad;
    }

    public String getAccesibilidad() {
        return Accesibilidad;
    }

    public void setAccesibilidad(String Accesibilidad) {
        this.Accesibilidad = Accesibilidad;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }

    public String getCondiciones() {
        return Condiciones;
    }

    public void setCondiciones(String Condiciones) {
        this.Condiciones = Condiciones;
    }
    
    
}
