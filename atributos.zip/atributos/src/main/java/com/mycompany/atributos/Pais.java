/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atributos;

/**
 *
 * @author Santy
 */
public class Pais {
    
    private String nombre;
private String capital;
private String idiomas;
private String moneda;
private String sistemaPolitico;
private String poblacion;
private String superficie;
private String husosHorarios;
private String prefijoTelefonico;
private String dominioInternet;
private String ubicacion;
private String clima;
private String relieve;
private String recursosNaturales;
private String exportaciones;
private String importaciones;
private String principalesCiudades;
private String festividadesNacionales;
private String educacion;
private String salud;
private String transporte;
private String economia;
private String turismo;
private String deportes;
private String gastronomia;
private String arte;
private String musica;
private String literatura;
private String cine;
private String television;
private String internet;
private String mediosComunicacion;
private String historia;
private String monumentos;
private String patrimonioCultural;
private String tradiciones;
private String bandera;
private String escudo;
private String himnoNacional;
private String lemaNacional;
private String simbolosNacionales;
private String diaNacional;

}
