/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atributos;

/**
 *
 * @author Santy
 */
public class ciudad {
    
    private String nombre;
private int poblacion;
private double superficie;
private String pais;
private String continente;
private int densidadPoblacional;
private double tasaCrecimientoPoblacional;
private int esperanzaVida;
private double indiceDesarrolloHumano;
private String idiomasOficiales;
private String moneda;
private String sistemaPolitico;
private String alcaldia;
private String cuerpoPolicial;
private String cuerpoBomberos;
private String cuerpoAmbulancias;
private String sistemaTransportePublico;
private int cantidadHospitales;
private int cantidadEscuelas;
private int cantidadUniversidades;
private int cantidadMuseos;
private int cantidadParques;
private int cantidadCentrosComerciales;
private String equipoDeportivo;
private String estadioDeportivo;
private int cantidadCines;
private int cantidadTeatros;
private String clima;
private int nivelContaminacion;
private boolean tieneRascacielos;
private boolean tienePlayas;
private boolean tieneMontañas;
private boolean tieneParquesNaturales;
private boolean tieneSitiosHistoricos;
private boolean tieneGastronomiaTipica;
private boolean tieneFestivalesCulturales;
}
