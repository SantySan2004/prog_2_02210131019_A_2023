/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atributos;

/**
 *
 * @author Santy
 */
public class edificio {
    private String nombre;
private String direccion;
private String ciudad;
private String pais;
private int anioConstruccion;
private int cantidadPisos;
private int cantidadApartamentos;
private int cantidadLocalesComerciales;
private int cantidadOficinas;
private int cantidadEstacionamientos;
private int cantidadElevadores;
private boolean accesoDiscapacitados;
private boolean seguridad;
private boolean camarasSeguridad;
private boolean sistemaAlarmas;
private boolean controlAcceso;
private boolean aireAcondicionadoCentral;
private boolean calefaccionCentral;
private boolean sistemaIncendios;
private boolean generadorElectricidad;
private boolean panelesSolares;
private boolean sistemaAguaCaliente;
private boolean sistemaAguaPotable;
private boolean sistemaGas;
private boolean ascensorCarga;
private boolean ascensorMudanza;
private boolean terraza;
private boolean piscina;
private boolean gimnasio;
private boolean salonFiestas;
private boolean areaInfantil;
private boolean areaVerde;
private boolean salaCine;
private boolean salaJuegos;
private boolean lavanderia;
private boolean servicioConserjeria;
private boolean servicioMantenimiento;
private boolean servicioLimpieza;
    
}
