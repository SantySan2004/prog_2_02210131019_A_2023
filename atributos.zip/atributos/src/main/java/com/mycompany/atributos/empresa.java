/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atributos;

/**
 *
 * @author Santy
 */
public class empresa {
    
    private String nombre;
private String razonSocial;
private String sector;
private String direccion;
private int telefono;
private String correoElectronico;
private String sitioWeb;
private String descripcion;
private int numeroEmpleados;
private int anioFundacion;
private double ingresosAnuales;
private double gananciasNetas;
private double activosTotales;
private double pasivosTotales;
private int numeroSucursales;
private String paisOrigen;
private String mision;
private String vision;
private String valores;
private boolean certificacionCalidad;
private boolean certificacionAmbiental;
private boolean certificacionResponsabilidadSocial;
private boolean certificacionSeguridadLaboral;
private boolean certificacionISO;
private boolean certificacionOtros;
private boolean presenciaInternacional;
private boolean filiales;
private boolean subsidiarias;
private boolean franquicias;
private boolean jointVentures;
private boolean licencias;
private boolean patentes;
private boolean propiedadIntelectual;
private boolean innovacion;
private boolean investigacion;
private boolean desarrollo;
private boolean tecnologia;
private boolean marketing;
private boolean publicidad;
private boolean relacionesPublicas;
private boolean ventas;
private boolean distribucion;
private boolean logistica;
private boolean cadenaSuministro;
private boolean finanzas;
private boolean contabilidad;
private boolean recursosHumanos;
private boolean juridico;
private boolean informatica;
private boolean seguridadInformacion;

}
