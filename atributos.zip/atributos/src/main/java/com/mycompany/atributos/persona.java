/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atributos;

/**
 *
 * @author Santy
 */
public class persona {
    
    private String nombre;
private String apellido;
private String genero;
private String fechaNacimiento;
private int edad;
private String direccion;
private String ciudad;
private String pais;
private String correoElectronico;
private String numeroTelefono;
private String estadoCivil;
private String ocupacion;
private int ingresoMensual;
private int estatura;
private int peso;
private String tipoSanguineo;
private boolean donanteOrganos;
private boolean donanteSangre;
private boolean fumador;
private boolean bebedor;
private boolean consumeDrogas;
private boolean tieneAlergias;
private boolean tieneEnfermedadesCronicas;
private boolean tieneDiscapacidades;
private boolean practicaDeporte;
private boolean esVegetariano;
private boolean tieneMascotas;
private int cantidadHijos;
private String religion;
private boolean tieneTatuajes;
private boolean tienePiercings;
private String idiomas;
}
