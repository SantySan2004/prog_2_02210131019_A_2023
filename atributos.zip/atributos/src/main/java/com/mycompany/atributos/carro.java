/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atributos;

/**
 *
 * @author Santy
 */
public class carro {
    
    private String marca;
private String modelo;
private int anio;
private String tipoCarroceria;
private int cantidadPuertas;
private int cantidadAsientos;
private int capacidadMaletero;
private int capacidadTanque;
private int consumoCiudad;
private int consumoCarretera;
private int potencia;
private int torque;
private int traccion;
private int suspension;
private int frenos;
private int transmision;
private int marchas;
private int seguridad;
private int asistenciaConductor;
private int entretenimiento;
private int navegacion;
private int climatizacion;
private int iluminacion;
private int audio;
private int conectividad;
private int asientos;
private int ventanas;
private int retrovisores;
private int limpiaparabrisas;
private int calefaccion;
private int refrigeracion;
private int direccion;
private int controlCrucero;
private int alertaPuntoCiego;
private int alertaCambioCarril;
private int alertaColision;
private int frenadoEmergencia;
private int arranquePendiente;
private int asistenciaEstacionamiento;
private int monitoreoPresionNeumaticos;
private boolean farosLED;
private boolean farosXenon;
private boolean farosAntiniebla;
private boolean lucesDiurnasLED;
private boolean lucesTraserasLED;
private boolean lucesGiroLED;
private boolean lucesPosicionLED;
private boolean lucesFrenoLED;
private boolean sensorLluvia;
private boolean sensorLuz;
private boolean sensorEstacionamientoTrasero;
private boolean sensorEstacionamientoDelantero;
private boolean camaraTrasera;
private boolean camaraDelantera;
private boolean retrovisoresPlegablesElectricamente;
private boolean asientosDelanterosCalefaccion;
private boolean asientosDelanterosVentilacion;
private boolean asientosTraserosCalefaccion;
private boolean asientosTraserosVentilacion;
private boolean asientoConductorAjusteElectrico;
private boolean asientoPasajeroAjusteElectrico;
private boolean asientosTraserosAbatibles;
private boolean compartimentoCarga;
private boolean puertaTraseraElectricamente;
private boolean arranqueRemoto;
private boolean accesoSinLlave;
private boolean llantasRepuesto;
private boolean kitHerramientasEmergencia;
private boolean triangulosSeguridad;
    
}
