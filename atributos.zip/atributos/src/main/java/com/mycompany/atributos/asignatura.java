/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atributos;

/**
 *
 * @author Santy
 */
public class asignatura {
    
    private String nombre;
private int codigo;
private String descripcion;
private String tipo;
private int creditos;
private int horasSemanales;
private int horasSemestrales;
private String prerequisitos;
private String coRequisitos;
private String objetivosGenerales;
private String objetivosEspecificos;
private String competencias;
private String contenidosTematicos;
private String metodologia;
private String evaluacion;
private String bibliografiaBasica;
private String bibliografiaComplementaria;
private String plataformaVirtual;
private String foro;
private String chat;
private String correo;
private String videoConferencia;
private String materialDidactico;
private String tutorias;
private String laboratorio;
private String talleres;
private String proyectos;
private String examenes;
private String trabajosInvestigacion;
private String practicasEmpresariales;
private String practicasProfesionales;

}
