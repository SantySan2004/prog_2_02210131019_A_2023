/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atributos;

/**
 *
 * @author Santy
 */
public class computador {
    
    private String marca;
private String modelo;
private int anioFabricacion;
private double velocidadProcesador;
private int cantidadNucleos;
private int cantidadHilos;
private int memoriaRam;
private int capacidadDiscoDuro;
private boolean tieneUnidadCD;
private boolean tieneUnidadDVD;
private boolean tieneBluetooth;
private boolean tieneWifi;
private boolean tienePuertoEthernet;
private boolean tienePuertoHDMI;
private boolean tienePuertoVGA;
private boolean tienePuertoUSB2;
private boolean tienePuertoUSB3;
private boolean tienePuertoThunderbolt;
private boolean tieneLectorTarjetaSD;
private boolean tieneLectorTarjetaMicroSD;
private boolean tieneCamaraWeb;
private boolean tieneMicrofono;
private boolean tieneAltavoces;
private boolean tienePantallaTactil;
private boolean tieneTecladoRetroiluminado;
private boolean tieneTrackpad;
private boolean tieneSensorHuella;
private boolean tieneSensorProximidad;
private boolean tieneSensorLuzAmbiente;
private boolean tieneSistemaOperativo;
    
}
