/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atributos;

/**
 *
 * @author Santy
 */
public class mascota {
    
    private String nombre;
private String especie;
private String raza;
private int edad;
private String color;
private double peso;
private double altura;
private String genero;
private boolean esterilizado;
private boolean vacunado;
private boolean desparasitado;
private boolean adiestrado;
private boolean microchip;
private boolean pedigree;
private String dieta;
private String alergias;
private String enfermedades;
private String medicamentos;
private String juguetesFavoritos;

}
