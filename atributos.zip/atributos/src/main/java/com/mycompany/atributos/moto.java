/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atributos;

/**
 *
 * @author Santy
 */
public class moto {
    
    private String marca;
private String modelo;
private int anio;
private int cilindrada;
private int potencia;
private int torque;
private int suspensionDelantera;
private int suspensionTrasera;
private int frenosDelanteros;
private int frenosTraseros;
private int transmision;
private int marchas;
private int tipoCombustible;
private int capacidadTanque;
private int consumoCiudad;
private int consumoCarretera;
private int velocidadMaxima;
private int aceleracion;
private boolean arranqueElectrico;
private boolean arranquePatada;
private boolean frenosABS;
private boolean controlTraccion;
private boolean controlEstabilidad;
private boolean lucesDelanterasLED;
private boolean lucesTraserasLED;
private boolean sistemaAudio;
private boolean conectividad;
private boolean pantallaTactil;
}
